package com.example.bubaleapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.parse.ParseFile;

import java.util.List;

public class detailAdapter extends RecyclerView.Adapter<detailAdapter.ViewHolder>{

    private static final String TAG = "itemAdapter";
    private Context context;
    private List<item> items;


    public detailAdapter(Context context, List<item> items){
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public detailAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_detail, parent, false);
        return new detailAdapter.ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull detailAdapter.ViewHolder holder, int position) {
        item item = items.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tvTitle;
        private TextView tvDesc;
        private TextView tvPrice;
        private ImageView ivImage;
        private TextView tvDesc2;


        public ViewHolder(View view) {
            super(view);
            tvTitle = view.findViewById(R.id.tvTitle);
            tvDesc = view.findViewById(R.id.tvDesc);
            tvPrice = view.findViewById(R.id.tvPrice);
            ivImage = view.findViewById(R.id.ivPic);
            tvDesc2 = view.findViewById(R.id.tvDesc2);


        }

        public void bind(item item) {
            tvTitle.setText(item.getTitle());
            tvDesc.setText(item.getDescription());
            tvPrice.setText(item.getPrice() + " USD");
            tvDesc2.setText(item.getDes2());
            ParseFile image = item.getImage();
            if(image !=null){
                Glide.with(context).load(item.getImage().getUrl()).into(ivImage);
            }

        }
    }
}
