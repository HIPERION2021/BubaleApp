package com.example.bubaleapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.bubaleapp.fragments.checkoutFragment;
import com.example.bubaleapp.fragments.homeFragment;
import com.example.bubaleapp.fragments.profileFragment;
import com.example.bubaleapp.fragments.shopFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.parse.ParseUser;


public class MainActivity extends AppCompatActivity {

    final FragmentManager fragmentManager = getSupportFragmentManager();
    private BottomNavigationView mainmenu;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_main);

        mainmenu = findViewById(R.id.navbar);
        mainmenu.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = new Fragment();
                    switch (item.getItemId()){
                        case R.id.action_home:
                            fragment = new homeFragment();
                        break;
                        case R.id.action_shop:
                            fragment = new shopFragment();
                        break;
                        case R.id.action_logout:
                            logout();
                        break;
                        case R.id.action_profile:
                            fragment = new profileFragment();
                        break;
                        default:
                            break;
                    }
                fragmentManager.beginTransaction().replace(R.id.maincont, fragment).commit();

                return false;
            }
        });
        mainmenu.setSelectedItemId(R.id.action_shop);
    }

    private void logout() {
        ParseUser.logOut();
        ParseUser currentUser = ParseUser.getCurrentUser();
        gotologin();
    }

    private void gotologin() {
        Intent log = new Intent(MainActivity.this, Login.class);
        startActivity(log);
        finish();
    }

}