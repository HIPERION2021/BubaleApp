package com.example.bubaleapp.fragments;

import android.content.ClipData;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.bubaleapp.R;
import com.example.bubaleapp.item;
import com.example.bubaleapp.itemAdapter;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class shopFragment extends Fragment {

    public static final String TAG = "ShopFragment";
    private RecyclerView rvItems;
    protected itemAdapter adapter;
    protected List<item> allItems;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_shop, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvItems = view.findViewById(R.id.rvItems);
        allItems = new ArrayList<>();
        adapter = new itemAdapter(getContext(), allItems);
        rvItems.setAdapter(adapter);
        rvItems.setLayoutManager(new LinearLayoutManager(getContext()));


        queryItems();


    }

    private void queryItems() {
        ParseQuery<item> query =  ParseQuery.getQuery(item.class);
        query.include(item.KEY_TITLE);
        query.setLimit(20);
        query.addDescendingOrder(item.KEY_CRATED_KEY);
        query.findInBackground(new FindCallback<item>() {
            @Override
            public void done(List<item> items, ParseException e) {
                if(e !=null){
                    Log.e(TAG, "Issue with getting items", e);
                    return;
                }

                allItems.addAll(items);
                adapter.notifyDataSetChanged();

            }
        });
    }
}